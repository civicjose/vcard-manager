

<?php $__env->startSection('title', 'Listado de Empresas'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Listado de Empresas</h1>
    <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-primary">Añadir nueva Empresa</a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<table class="table table-hover table-bordered">
    <thead class="table-dark">
        <tr>
            <th>Nombre</th>
            <th>Logo</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($company->name); ?></td>
                <td>
                    <?php if($company->logo): ?>
                        <img src="<?php echo e(asset('storage/' . $company->logo)); ?>" alt="Logo de <?php echo e($company->name); ?>" class="img-fluid" width="100">
                    <?php else: ?>
                        Sin logo
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('companies.edit', $company->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                    <form action="<?php echo e(route('companies.destroy', $company->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="button" class="btn btn-danger btn-sm btn-delete">Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcard-app\resources\views/companies/index.blade.php ENDPATH**/ ?>