

<?php $__env->startSection('title', 'Crear nueva Empresa'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>Crear nueva Empresa</h2>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('companies.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="name" class="form-label">Nombre de la Empresa</label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
            </div>

            <div class="mb-3">
                <label for="logo" class="form-label">Logo (SVG)</label>
                <input type="file" name="logo" id="logo" class="form-control" accept=".svg">
            </div>

            <button type="submit" class="btn btn-success">Crear Empresa</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vcard-app\resources\views/companies/create.blade.php ENDPATH**/ ?>