

<?php $__env->startSection('title', 'Listado de vCards'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h2">Listado de vCards</h1>
    <a href="<?php echo e(route('vcards.create')); ?>" class="btn btn-primary">Añadir nueva vCard</a>
</div>

<!-- Campo de búsqueda -->
<div class="mb-3">
    <input type="text" id="search" class="form-control" placeholder="Buscar por nombre, apellidos, teléfono, empresa..." onkeyup="searchTable()">
</div>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<table class="table table-hover table-bordered" id="vcardTable">
    <thead class="table-dark">
        <tr>
            <th>Nombre</th>
            <th>Apellidos</th>
            <th>Puesto</th>
            <th>Teléfono</th>
            <th>Empresa</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $vcards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vcard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($vcard->name); ?></td>
            <td><?php echo e($vcard->lastname); ?></td>
            <td><?php echo e($vcard->position); ?></td>
            <td><?php echo e($vcard->phone); ?></td>
            <td>
                <?php if($vcard->company): ?>
                <?php echo e($vcard->company->name); ?>

                <?php else: ?>
                Sin empresa
                <?php endif; ?>
            </td>
            <td>
                <a href="<?php echo e(route('vcards.show', [$vcard->slug])); ?>" class="btn btn-info btn-sm" target="_blank">Ver</a>
                <a href="<?php echo e(route('vcards.edit', $vcard->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                <form action="<?php echo e(route('vcards.destroy', $vcard->id)); ?>" method="POST" style="display:inline-block;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="button" class="btn btn-danger btn-sm btn-delete">Eliminar</button>
                </form>
                <!-- Botón para ver el QR -->
                <?php
                $qrUrl = asset('storage/' . $vcard->qr_code);
                ?>

                <?php if($vcard->qr_code): ?>
                <button type="button" class="btn btn-secondary btn-sm" onclick="showQrCode('<?php echo e($qrUrl); ?>')">Ver QR</button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<!-- Modal para mostrar el QR -->
<div id="qrModal" class="modal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Código QR</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body text-center">
                <img id="qrImage" src="" alt="Código QR" class="img-fluid">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<script>
    function searchTable() {
        let input = document.getElementById('search').value.toLowerCase();
        let rows = document.querySelectorAll('#vcardTable tbody tr');

        rows.forEach(row => {
            let text = row.innerText.toLowerCase();
            row.style.display = text.includes(input) ? '' : 'none';
        });
    }

    function showQrCode(imageUrl) {
        var qrModal = new bootstrap.Modal(document.getElementById('qrModal'));
        document.getElementById('qrImage').src = imageUrl;
        qrModal.show();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose Cívico\vcard-app\resources\views/vcards/index.blade.php ENDPATH**/ ?>